import subprocess
import sys
import os
import urllib.request

# List of packages to install
packages = [
    'opencv-python',
    'numpy',
    'beautifulsoup4',
    'reportlab',
    'svglib',
    'PyMuPDF',
    'glob2'
]

def install_package(package):
    subprocess.check_call([sys.executable, '-m', 'pip', 'install', package])

def ensure_pip():
    try:
        import pip
    except ImportError:
        get_pip_url = "https://bootstrap.pypa.io/get-pip.py"
        get_pip_script = "get-pip.py"
        urllib.request.urlretrieve(get_pip_url, get_pip_script)
        subprocess.check_call([sys.executable, get_pip_script])
        os.remove(get_pip_script)

def ensure_python():
    try:
        subprocess.check_call([sys.executable, '--version'])
    except FileNotFoundError:
        sys.exit("Python is not installed. Please install Python from https://www.python.org/downloads/")

def check_and_install_packages(packages):
    ensure_python()
    ensure_pip()

    for package in packages:
        try:
            __import__(package.split('-')[0])
        except ImportError:
            install_package(package)

if __name__ == "__main__":
    check_and_install_packages(packages)
    print("Finished successfully.")
