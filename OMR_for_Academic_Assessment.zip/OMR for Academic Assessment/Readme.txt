OMR Response Reader and Custom OMR Editor

##Installation##
First, install all the required dependencies. Ensure that Python and all necessary libraries are installed.
-->py install_dependencies.py


##Usage##
1.Reading OMR Responses
	To use the OMR Response Reader, place the desired PDFs in a folder named `answerpaper`. Then, run the following command:
	-->python reader.py

2.Inserting a Logo
	To insert a logo into OMR, place the logo file (in SVG format) in the same folder as the program. Then, use the following command:
	-->python customOMR.py insertLogo template.svg YourLogo.svg OutputSvgName.svg

	- `template.svg`: The OMR template where the logo will be inserted.
	- `YourLogo.svg`: The SVG file of the logo to be inserted.
	- `OutputSvgName.svg`: The name of the output file with the logo included.

3.Prefilling the OMR
	To prefill the OMR sheet with specific data, specify the script version and the number of copies you want:
	-->python customOMR.py prefillOMR template.svg OutputSvgName 45658793214524 5

	- `template.svg`: The OMR template to be prefilled.
	- `OutputSvgName`: The name for the output files.
	- `45658793214524`: The script version.
	- `5`: The number of copies to generate.

4.Editing Captions
	To replace captions on the OMR sheet, place the text file containing the new captions in the same folder as the program. Then, run:
	-->python customOMR.py replaceText template.svg config.txt OutputSvgName.svg

	- `template.svg`: The OMR template where captions will be replaced.
	- `config.txt`: The text file with the new captions.
	- `OutputSvgName.svg`: The name of the output file with updated captions.

5.Combining Multiple Functions
	You can combine the above three functions into a single command. Use the following syntax:
	-->python customOMR.py combine template.svg config.txt logoName.svg 14253678915975 5 OutputSvgName

	- `template.svg`: The OMR template to be used.
	- `config.txt`: The text file with the new captions.
	- `logoName.svg`: The SVG file of the logo to be inserted.
	- `14253678915975`: The script version or code to be prefilled.
	- `5`: The number of copies to generate.
	- `OutputSvgName`: The base name for the output files.
